/*
 * pic_link.h  -  Framed packet link to the PIC18F06Q40 flow meter (V040).
 *
 * Implements the "PIC <-> Photon2 Interface Specification" (Flow-Meter Packet
 * Protocol, WAKE handshake, Leak/Valve control). This REPLACES the old raw
 * single-byte link (0xF0 wake + 0xAA -> raw COUNT+samples) and the home-grown
 * 0xC0 config frame. From V040 everything after wake-up is a CRC-framed packet.
 *
 *   Link        : UART 38400 8N1 on Serial1, 3.3 V. PIC = peripheral, P2 = host.
 *   Frame       : AA 55 | func | len_hi len_lo | data[len] | crc_hi crc_lo
 *   Endianness  : every multi-byte field is big-endian / MSB-first.
 *   CRC         : CRC-16/MODBUS (poly 0xA001, init 0xFFFF, no final XOR),
 *                 over func+len+data (AA 55 excluded), sent big-endian.
 *
 * POWER-GATING MODEL (PIC firmware V048): the D10 WAKE handshake is GONE. RC4 on
 * the PIC no longer signals "comms ready" on D10; it now drives a P-MOS that
 * switches the Photon's SUPPLY (RC4 LOW -> powered, RC4 HIGH -> unpowered). So
 * "being powered" already means "the PIC wants a session -- talk now". The
 * Photon therefore never checks D10, never sends 0xF0, and cannot wake itself.
 * It ends each session with PKT_PHOTON_OFF_REQ (func 0x07) so the PIC cuts power.
 *
 * Send rule: send immediately (the PIC is powered and listening whenever we run).
 * wakeIsHigh()/waitWakeHigh()/ensureWake() are kept only so old callers compile;
 * they now always report "ready". One REQ at a time: wait for its RSP before
 * sending anything else; resend on timeout/bad CRC. D10 stays pulled up, unused.
 *
 * BEGINNER NOTE:
 *   This header DECLARES (announces) a class called PicLink and the data
 *   structures it uses. The actual code that DOES the work lives in
 *   pic_link.cpp. A header is like a table of contents / promise list; the .cpp
 *   is where the promises are kept.
 *
 *   "Framed packet" means every message is wrapped in a fixed envelope so the
 *   receiver can tell where a message starts, how long it is, and whether it
 *   arrived intact (that is the job of the CRC check at the end).
 */

#pragma once             // Include this header only once per build (avoids duplicate definitions).
#include "Particle.h"    // Device-OS library: gives us Serial1, digitalRead(), millis(), etc.
#include "app_config.h"  // Our own settings file (pin numbers, timeouts, default parameters).

// 10-bit sample index -> at most 1024; the protocol caps a batch at 1000.
#define PIC_BYTES_PER_SAMPLE 3      // Each flow sample is packed into exactly 3 bytes on the wire.
#define PIC_MAX_SAMPLES      1000u  // We never expect more than 1000 samples in one batch ('u' = unsigned).

// ---- Frame constants --------------------------------------------------------
// An "enum" here just gives readable names to fixed byte values.
enum {
  PIC_MARK0 = 0xAA,        // First marker byte that begins every frame (hex AA = 170).
  PIC_MARK1 = 0x55,        // Second marker byte (hex 55 = 85). "AA 55" together = "a frame starts here".
  PIC_WAKE_BYTE = 0xF0     // (Unused under power-gating.) Formerly the wake byte; the PIC is always
                           //   powered/listening whenever we run, so we never send 0xF0 anymore.
};

// ---- Function codes (spec 3) ------------------------------------------------
// These name the "type" of each message. REQ_* = we ask; RSP_* = the PIC answers.
enum {
  REQ_DATA         = 0x01,   // -> RSP_DATA      : ask the PIC for its stored flow samples.
  REQ_GET_PARAM    = 0x02,   // -> RSP_PARAM     : ask the PIC for its 4 leak parameters.
  REQ_SET_PARAM    = 0x03,   // 4xu16 -> RSP_ACK/NAK : send the PIC new leak parameters.
  REQ_GET_VALVE    = 0x04,   // -> RSP_VALVE     : ask the PIC for valve status.
  REQ_VALVE_UNLOCK = 0x05,   // 1B flags -> RSP_ACK/NAK : tell the PIC to clear a valve lock.
  PKT_SYS_RESET    = 0x06,   // (no reply)       : tell the PIC to reset itself.
  PKT_PHOTON_OFF_REQ = 0x07, // (no reply)       : Photon -> PIC "cut my power, I'm done".
  REQ_POWER_STATE  = 0x08,   // -> RSP_POWER_STATE : ask if the PIC is in its initial power-hold (no payload).
  REQ_PHOTON_CFG   = 0x09,   // -> RSP_PHOTON_CFG : ask the PIC for our timing+debug config (no payload).
  PKT_KEEPALIVE    = 0x0A,   // (no reply)       : Photon -> PIC "alive, still connecting"; keeps PIC power up.
  REQ_SET_SCHEDULE = 0x0B,   // u16 remaining captures -> RSP_ACK/NAK : re-anchor the PIC's
                             //   report-due countdown so the next report lands at a chosen
                             //   wall-clock hour (see syncPublishSchedule()). PIC has no RTC.
  RSP_DATA         = 0x81,   // The PIC's reply carrying flow samples.
  RSP_PARAM        = 0x82,   // The PIC's reply carrying its 4 leak parameters.
  RSP_VALVE        = 0x84,   // The PIC's reply carrying valve status.
  RSP_POWER_STATE  = 0x88,   // PIC reply to REQ_POWER_STATE: data[0] = 0 INITIAL / 1 NORMAL.
  RSP_PHOTON_CFG   = 0x89,   // PIC reply to REQ_PHOTON_CFG: 13-byte config block (see PicPhotonCfg).
  RSP_ACK          = 0x8E,   // The PIC's "OK, request accepted" reply.
  RSP_NAK          = 0x8F    // The PIC's "request rejected" reply (reason byte follows).
};

// ---- NAK reasons (RSP_NAK data[0], spec 3) ----------------------------------
// When the PIC says "rejected" (NAK), it includes one of these reason codes.
enum {
  NAK_BAD_CRC  = 0x01,   // The PIC thought our message was corrupt (CRC mismatch).
  NAK_BAD_LEN  = 0x02,   // The PIC thought our length field was wrong.
  NAK_BAD_FUNC = 0x03,   // The PIC did not recognize our function code.
  NAK_BUSY     = 0x04    // The PIC is busy and cannot serve the request right now.
};

// ---- Result codes (negative = failure) --------------------------------------
// Our own functions return one of these. 0 means success; negatives mean errors.
enum {
  PIC_OK            =  0,   // Everything worked.
  PIC_ERR_NO_WAKE   = -1,   // WAKE never went HIGH after 0xF0  (PIC never woke up).
  PIC_ERR_TIMEOUT   = -2,   // no (complete) response in time   (PIC stayed silent).
  PIC_ERR_BAD_CRC   = -3,   // response framed but CRC failed    (reply arrived corrupted).
  PIC_ERR_BAD_FRAME = -4,   // marker/len garbage                (reply was malformed).
  PIC_ERR_WRONG_RSP = -5,   // valid frame, unexpected func      (got a reply of the wrong type).
  PIC_ERR_NAK       = -6,   // PIC returned RSP_NAK (see lastNak())  (request understood but rejected).
  PIC_ERR_OVERFLOW  = -7    // response longer than caller buffer (reply too big to store).
};

// ---- Payload structs --------------------------------------------------------
// These structs describe the DECODED contents of messages, in easy-to-use form.
struct PicSample {           // decoded 10-14 packed sample
                             //   One flow reading after we unpack it from 3 raw bytes.
  uint16_t index;            // 0..1023 (high 10 bits)   : which time-slot this sample belongs to.
  uint16_t pulses;           // 0..16383 (low 14 bits)   : how many flow pulses were counted.
};

// V051 extended RSP_DATA header, decoded from the 18-byte prefix that now
// precedes the samples. Lets the host detect distortion (span > sum of clamped
// samples) and know that no total flow is lost even if the series was truncated.
struct PicReportInfo {
  uint32_t impulseSinceReport;   // 1: true pulses since the last report (never lost)
  uint32_t capturesSinceReport;  // 2: captures since the last report
  uint32_t impulseOfSpan;        // 3: true pulses of the sent sample span (unclamped)
  uint16_t overflowCount;        // 4: #samples in the span clamped at 14 bits
  uint32_t count;                // 5: #samples that follow
};

struct PicParams {           // REQ_SET_PARAM / RSP_PARAM payload (4xu16 BE)
                             //   The PIC's four leak-detection settings.
  uint16_t leak1_counts;     // alert 1 threshold (counts)  -> temporary lock
  uint16_t leak1_window_s;   // alert 1 window (seconds)
  uint16_t leak2_counts;     // alert 2 threshold (counts)  -> permanent lock
  uint16_t leak2_window_s;   // alert 2 window (seconds)
};

// ---- config the PIC hands us at boot (RSP_PHOTON_CFG, 0x89) ------------------
// The PIC is the single source of truth for the sample TIMING (so PIC and Photon
// can never disagree -> no more GPM/gallon mismatch) and for the DEBUG toggles
// (so we retune from the PIC's fast ~30 s build instead of reflashing the Photon).
// If provided==false the PIC told us to use our own compiled defaults.
struct PicPhotonCfg {
  bool     provided;          // true = PIC supplied these; false = use our defaults
  uint8_t  version;           // wire-format version
  uint32_t captureIntervalMs; // real per-sample window in ms (rate divisor x1000)
  uint16_t samplesPerReport;  // PIC's APP_SAMPLES_PER_REPORT
  uint8_t  reportIntervalHr;  // PIC's REPORT_INTERVAL_HR (24 or 48) -- drives the Photon's
                             //   hourly-bin width (see leaksense.cpp: hourlyBinWidthHours()).
  bool     fastBench;         // true = skip cloud (virtual clock, sim publish)
  bool     debugDataseries;   // true = stream per-sample lines over USB-CDC
  uint8_t  missedFillMode;    // 0 = ZERO, 1 = AVERAGE
  uint16_t serialDelayMs;     // boot delay before the log burst
};

struct PicValve {            // RSP_VALVE payload (5 B)
                             //   The current state of the PIC's motorized valve.
  uint8_t  pwr_pin;          // VALVE_PWR  level (0/1)     : is valve power on?
  uint8_t  ctrl_pin;         // VALVE_CTRL level (0/1)     : valve direction signal.
  uint8_t  motion;           // 0..6 (see spec 4.3)        : current valve motion state.
  uint8_t  lock_flags;       // bit0=temp, bit1=perm (0x03=both) : which locks are currently ACTIVE.
  uint8_t  leakSinceReport;  // bit0=LEAK1(temp), bit1=LEAK2(perm) : tripped since the PIC last sent this.
                             //   Transient -- the PIC clears it right after sending. The Photon owns the
                             //   lifetime tally (leakingEventCount/overflowEventCount in leaksense.cpp),
                             //   incrementing once per bit seen set here, reset only by the MODE button.
};

// Valve lock bit layout (shared by lock_flags and the UNLOCK command).
// These single-bit values can be combined (added) to mean "both".
enum {
  VALVE_LOCK_TEMP = 0x01,    // Bit 0 set = a TEMPORARY lock is active (auto-clears after ~10 min).
  VALVE_LOCK_PERM = 0x02,    // Bit 1 set = a PERMANENT lock is active (needs unlock or reset).
  VALVE_LOCK_BOTH = 0x03     // Both bits set (0x01 | 0x02 = 0x03) = both locks at once.
};

// ---- PKT_PHOTON_OFF_REQ reasons (data[0], power-gating model) ---------------
// The PIC now switches the Photon's SUPPLY through a P-MOS on RC4, so the Photon
// ends every session by telling the PIC "cut my power". data[0] says why.
enum PhotonOffReason : uint8_t {
  OFF_REASON_DONE       = 0x00,   // all comms finished normally
  OFF_REASON_CLOUD_FAIL = 0x01    // could not reach the cloud
};

// ---- REQ_POWER_STATE / RSP_POWER_STATE (boot power-hold handshake) ----------
// At a cold power-up the PIC (V049) may hold the Photon FULLY POWERED for an initial
// ~10-minute window so the flow meter can be watched live. RSP_POWER_STATE data[0]
// tells the Photon which mode it is in. In INITIAL the Photon must STAY POWERED and
// must NOT send func 0x07 -- the PIC owns the window and cuts power when it ends.
enum {
  POWER_STATE_INITIAL = 0,   // Cold-boot hold active: stay powered; the PIC cuts power at ~10 min.
  POWER_STATE_NORMAL  = 1    // Normal operation (or a WDT/soft reset): run a normal session.
};

// A "class" bundles related data and the functions that act on it. PicLink is
// our object that knows how to talk to the PIC chip.
class PicLink {
public:                                              // "public" = usable from outside the class.
  void begin(unsigned long baud = 38400);            // Set up the serial port + D10 pin. Default speed 38400.
  bool wakeIsHigh();                                 // Power-gating: always true (D10 no longer a comms signal).

  // REQ_DATA -> RSP_DATA. Decodes samples into out[]. Returns sample count
  // (>=0) or a PIC_ERR_* code (<0). Works for both host-initiated and
  // PIC-initiated uploads (the WAKE handshake no-ops when WAKE is already HIGH).
  int requestData(PicSample *out, uint16_t maxSamples, PicReportInfo *info = nullptr);  // Ask for flow data; fill out[] and (optionally) the V051 header fields.

  // REQ_GET_PARAM -> RSP_PARAM. true on success (out populated).
  bool getParams(PicParams &out);                    // Read the PIC's 4 leak parameters into 'out'.
  // REQ_SET_PARAM -> RSP_ACK/NAK. true only on ACK.
  bool setParams(const PicParams &in);               // Write 4 leak parameters from 'in' to the PIC.

  // REQ_SET_SCHEDULE -> RSP_ACK/NAK. true only on ACK. Re-anchors the PIC's
  // report-due countdown to fire after exactly 'remainingCaptures' more captures.
  bool setSchedule(uint16_t remainingCaptures);      // See syncPublishSchedule() in leaksense.cpp.

  // REQ_GET_VALVE -> RSP_VALVE. true on success (out populated).
  bool getValve(PicValve &out);                      // Read the valve status into 'out'.
  // REQ_VALVE_UNLOCK -> RSP_ACK/NAK. flags: VALVE_LOCK_*. true only on ACK.
  bool unlockValve(uint8_t flags);                   // Clear one or both valve locks.

  // PKT_SYS_RESET. No reply expected (the PIC resets and clears the perm lock).
  void sysReset();                                   // Tell the PIC to reboot.

  // PKT_PHOTON_OFF_REQ (func 0x07). One-way, no reply (like sysReset). Tells the
  // PIC "I'm done, cut my power". data[0]=reason (OFF_REASON_*). The PIC then
  // drives RC4 HIGH -> P-MOS off -> Photon unpowered. true if the frame was sent.
  bool sendPhotonOff(uint8_t reason);                // func 0x07, len 1, data[0]=reason; no reply.

  // PKT_KEEPALIVE (func 0x0A). One-way, no reply (like sysReset). Sent periodically
  // while waiting for the cloud so the PIC's ACTIVE idle backstop does not cut our
  // power mid-connect. Carries no payload/meaning beyond "I'm alive". true if sent.
  bool sendKeepalive();                              // func 0x0A, len 0; no reply.

  // REQ_POWER_STATE (func 0x08) -> RSP_POWER_STATE (0x88). Asks whether the PIC is in
  // its initial cold-boot power-hold. On success sets *out to the state byte
  // (POWER_STATE_INITIAL / POWER_STATE_NORMAL) and returns PIC_OK; otherwise returns a
  // PIC_ERR_* code and leaves *out unchanged. Sends no payload.
  int getPowerState(uint8_t *out);                   // Ask the PIC if it's in the initial power-hold.
  int getPhotonConfig(PicPhotonCfg *out);            // Ask the PIC for our timing+debug config (0x09).

  // Reason byte from the most recent RSP_NAK (0 if none).
  uint8_t lastNak() const { return _lastNak; }       // Tiny helper: report why the last request was rejected.
                                                     //   ("const" = this function does not change the object.)

private:                                             // "private" = internal-only; not callable from outside.
  // --- low level ---
  static uint16_t crc16(const uint8_t *p, uint16_t n);   // Compute the CRC-16 checksum over n bytes at p.
                                                         //   "static" = belongs to the class, not one object.
  bool ensureWake();                                   // spec 5.3 send rule : make sure the PIC is awake first.
  bool sendFrame(uint8_t func, const uint8_t *data, uint16_t len);  // Build + transmit one framed packet.
  // Read one framed packet; resynchronises on AA 55. Returns PIC_OK or PIC_ERR_*.
  int  readFrame(uint8_t *func, uint8_t *data, uint16_t cap,
                 uint16_t *outLen, uint32_t timeoutMs);  // Receive one packet and verify its CRC.
  // One full transaction with retry (spec 5.4 / 7): send REQ, wait for the
  // matching RSP. wantFunc is the expected reply func. Returns PIC_OK/PIC_ERR_*.
  int  transact(uint8_t reqFunc, const uint8_t *reqData, uint16_t reqLen,
                uint8_t wantFunc, uint8_t *rspData, uint16_t rspCap,
                uint16_t *rspLen, uint32_t timeoutMs);   // Send a request and wait for its reply, with retries.

  bool readByte(uint8_t *out, uint32_t timeoutMs);   // Read exactly one byte (or time out).
  bool waitWakeHigh(uint32_t timeoutMs);             // Wait until WAKE goes HIGH (or time out).
  void flushRx();                                    // Throw away any leftover bytes in the receive buffer.

  uint8_t _lastNak = 0;                              // Stores the most recent NAK reason (0 = none yet).
                                                     //   (The leading underscore is a naming style for "private".)

  // Scratch for assembling outgoing frames (max payload = RSP_DATA-ish; the
  // host only ever SENDS small payloads, so 16 B is plenty).
  uint8_t _txbuf[7 + 16];                            // Temporary buffer to build a frame: 7 overhead + 16 data bytes.
};                                                   // End of the class (note the required ";").